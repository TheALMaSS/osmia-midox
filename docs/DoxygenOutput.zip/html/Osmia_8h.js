var Osmia_8h =
[
    [ "OsmiaNestData", "classOsmiaNestData.html", "classOsmiaNestData" ],
    [ "Osmia_Nest", "classOsmia__Nest.html", "classOsmia__Nest" ],
    [ "Osmia_Base", "classOsmia__Base.html", "classOsmia__Base" ],
    [ "Osmia_Egg", "classOsmia__Egg.html", "classOsmia__Egg" ],
    [ "Osmia_Larva", "classOsmia__Larva.html", "classOsmia__Larva" ],
    [ "Osmia_Prepupa", "classOsmia__Prepupa.html", "classOsmia__Prepupa" ],
    [ "Osmia_Pupa", "classOsmia__Pupa.html", "classOsmia__Pupa" ],
    [ "Osmia_InCocoon", "classOsmia__InCocoon.html", "classOsmia__InCocoon" ],
    [ "Osmia_Female", "classOsmia__Female.html", "classOsmia__Female" ],
    [ "__OSMIA_DIST_SIZE", "Osmia_8h.html#ae8486d70a45ac333f6457f3f277d2335", null ],
    [ "TTypeOfOsmiaParasitoids", "Osmia_8h.html#a593faac1c5b3dac11b364acc1c346d2e", [
      [ "topara_Unparasitised", "Osmia_8h.html#a593faac1c5b3dac11b364acc1c346d2ea3b5b425bd9c0ff3b0ddc6bd0ab646dc6", null ],
      [ "topara_Bombylid", "Osmia_8h.html#a593faac1c5b3dac11b364acc1c346d2eaeca7890ab1f8a5a23f440d596284c258", null ],
      [ "topara_Cleptoparasite", "Osmia_8h.html#a593faac1c5b3dac11b364acc1c346d2eaa3cbb641f63f70b26b9db4ab3d499925", null ],
      [ "topara_foobar", "Osmia_8h.html#a593faac1c5b3dac11b364acc1c346d2eadff41f2d7264030b11fb5ba1dc81ae9f", null ]
    ] ],
    [ "TTypeOfOsmiaState", "Osmia_8h.html#ade3cca27bb9c91693899fa725c79c549", [
      [ "toOsmias_InitialState", "Osmia_8h.html#ade3cca27bb9c91693899fa725c79c549af4bd3fce0b345299023411ad5b447002", null ],
      [ "toOsmias_Develop", "Osmia_8h.html#ade3cca27bb9c91693899fa725c79c549ae8bd056196f238e68ac7ec73b4bff02b", null ],
      [ "toOsmias_NextStage", "Osmia_8h.html#ade3cca27bb9c91693899fa725c79c549a59f66e199d844feaf7b2fdcb6f438636", null ],
      [ "toOsmias_Disperse", "Osmia_8h.html#ade3cca27bb9c91693899fa725c79c549a06b77e4e9bb56a1a7bea0337039a8ef9", null ],
      [ "toOsmias_NestProvisioning", "Osmia_8h.html#ade3cca27bb9c91693899fa725c79c549a781bb06058e3775cac4556516fdd707f", null ],
      [ "toOsmias_ReproductiveBehaviour", "Osmia_8h.html#ade3cca27bb9c91693899fa725c79c549ab5a0f986f5fb99d75f1712b0eb77c733", null ],
      [ "toOsmias_Emerged", "Osmia_8h.html#ade3cca27bb9c91693899fa725c79c549a9cf096e217db718d52e6b8733a1fe783", null ],
      [ "toOsmias_Die", "Osmia_8h.html#ade3cca27bb9c91693899fa725c79c549aefb8f6e22aa50036275ccce6b47b566e", null ]
    ] ],
    [ "cfg_OsmiaTotalCocoonMassLoss", "Osmia_8h.html#a3e9e686bce43f3b03928014f216573b0", null ],
    [ "cfg_OsmiaTotalCocoonMassLossRange", "Osmia_8h.html#ae3483f0d38520c7f65ddda4d1ea6f87b", null ]
];
var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "Osmia", "dir_beadf148b26977315a270a1a6e022e41.html", "dir_beadf148b26977315a270a1a6e022e41" ]
];
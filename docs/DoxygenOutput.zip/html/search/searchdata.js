var indexSectionsWithContent =
{
  0: "1234567_abcdefghiklmnoprstuvwxyz~",
  1: "os",
  2: "io",
  3: "abcdefghikloprstuwz~",
  4: "acglmnopsxy",
  5: "ef",
  6: "t",
  7: "t",
  8: "_o",
  9: "1234567abcdefilmnoprstvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};


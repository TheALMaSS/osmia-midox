var searchData=
[
  ['killallsubsequentcells_0',['KillAllSubsequentCells',['../classOsmia__Nest.html#a0a4b91282494fed679c088a8c24481f4',1,'Osmia_Nest']]]
];

var searchData=
[
  ['5_201_20configuration_0',['5.1 Configuration',['../index.html#autotoc_md18',1,'']]],
  ['5_202_20inputs_1',['5.2 Inputs',['../index.html#autotoc_md19',1,'']]],
  ['5_203_20outputs_2',['5.3 Outputs',['../index.html#autotoc_md20',1,'']]],
  ['5_20configuration_20inputs_20and_20outputs_3',['5. Configuration, inputs and outputs',['../index.html#autotoc_md17',1,'']]]
];

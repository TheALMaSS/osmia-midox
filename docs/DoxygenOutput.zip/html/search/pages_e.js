var searchData=
[
  ['level_20control_0',['2.2 Population-level control',['../index.html#autotoc_md7',1,'']]],
  ['limitations_1',['6. Implementation differences and retained limitations',['../index.html#autotoc_md21',1,'']]]
];

var searchData=
[
  ['updateosmianesting_0',['UpdateOsmiaNesting',['../classOsmiaPolygonEntry.html#ad0de4fb7d4c6ef357c658382a54b9700',1,'OsmiaPolygonEntry::UpdateOsmiaNesting()'],['../classOsmia__Nest__Manager.html#aade3226194cee4f47632882c598e1a6c',1,'Osmia_Nest_Manager::UpdateOsmiaNesting()']]]
];

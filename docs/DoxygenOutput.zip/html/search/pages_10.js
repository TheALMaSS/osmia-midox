var searchData=
[
  ['nest_20search_20foraging_20and_20dispersal_0',['4.3 Nest search, foraging and dispersal',['../index.html#autotoc_md15',1,'']]],
  ['nests_20and_20spatial_20organisation_1',['2.3 Nests and spatial organisation',['../index.html#autotoc_md8',1,'']]]
];

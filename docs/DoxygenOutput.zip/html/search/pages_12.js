var searchData=
[
  ['parasitism_20and_20pesticides_0',['4.4 Mortality, parasitism and pesticides',['../index.html#autotoc_md16',1,'']]],
  ['pesticides_1',['4.4 Mortality, parasitism and pesticides',['../index.html#autotoc_md16',1,'']]],
  ['population_20level_20control_2',['2.2 Population-level control',['../index.html#autotoc_md7',1,'']]],
  ['provisioning_3',['4.2 Adult reproduction and provisioning',['../index.html#autotoc_md14',1,'']]]
];

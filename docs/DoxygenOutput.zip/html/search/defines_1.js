var searchData=
[
  ['osmia_5fpopulation_5fmanagerh_0',['Osmia_Population_ManagerH',['../Osmia__Population__Manager_8h.html#aec03a420e23c865a5b8f6156e5427603',1,'Osmia_Population_Manager.h']]]
];

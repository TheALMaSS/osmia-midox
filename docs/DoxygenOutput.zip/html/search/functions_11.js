var searchData=
[
  ['wintermortality_0',['WinterMortality',['../classOsmia__InCocoon.html#aba61dd7b9da3b7ab6059a44ef9586e5b',1,'Osmia_InCocoon']]],
  ['writepopulationdynamics_1',['WritePopulationDynamics',['../classOsmia__Population__Manager.html#adf725109037472cedcca0101c832c539',1,'Osmia_Population_Manager']]]
];

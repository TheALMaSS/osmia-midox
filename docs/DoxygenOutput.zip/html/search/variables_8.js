var searchData=
[
  ['s_5fforaged_5fresource_5fpesticide_5fscratch_0',['s_foraged_resource_pesticide_scratch',['../Osmia_8cpp.html#a426abfea81c230859b33a3fbf46e8e93',1,'Osmia.cpp']]],
  ['sex_1',['sex',['../classstruct__Osmia.html#a6a67cd57032f9213a963093d1658a444',1,'struct_Osmia']]]
];

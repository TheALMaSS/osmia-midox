var searchData=
[
  ['configuration_0',['5.1 Configuration',['../index.html#autotoc_md18',1,'']]],
  ['configuration_20inputs_20and_20outputs_1',['5. Configuration, inputs and outputs',['../index.html#autotoc_md17',1,'']]],
  ['control_2',['2.2 Population-level control',['../index.html#autotoc_md7',1,'']]],
  ['control_20flow_3',['3. Scheduling and control flow',['../index.html#autotoc_md9',1,'']]]
];

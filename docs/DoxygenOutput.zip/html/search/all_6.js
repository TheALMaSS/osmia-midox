var searchData=
[
  ['7_20reproducibility_20and_20version_20boundary_0',['7. Reproducibility and version boundary',['../index.html#autotoc_md22',1,'']]]
];

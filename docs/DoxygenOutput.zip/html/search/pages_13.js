var searchData=
[
  ['references_0',['References',['../index.html#autotoc_md23',1,'']]],
  ['reproducibility_20and_20version_20boundary_1',['7. Reproducibility and version boundary',['../index.html#autotoc_md22',1,'']]],
  ['reproduction_20and_20provisioning_2',['4.2 Adult reproduction and provisioning',['../index.html#autotoc_md14',1,'']]],
  ['retained_20limitations_3',['6. Implementation differences and retained limitations',['../index.html#autotoc_md21',1,'']]]
];

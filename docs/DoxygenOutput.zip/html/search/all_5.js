var searchData=
[
  ['6_20implementation_20differences_20and_20retained_20limitations_0',['6. Implementation differences and retained limitations',['../index.html#autotoc_md21',1,'']]]
];

var searchData=
[
  ['nest_0',['nest',['../classstruct__Osmia.html#a768ed61ccb1efd85e4e52ef2d8065f99',1,'struct_Osmia']]],
  ['nest_20search_20foraging_20and_20dispersal_1',['4.3 Nest search, foraging and dispersal',['../index.html#autotoc_md15',1,'']]],
  ['nests_20and_20spatial_20organisation_2',['2.3 Nests and spatial organisation',['../index.html#autotoc_md8',1,'']]]
];

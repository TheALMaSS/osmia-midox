var searchData=
[
  ['bicornis_20model_0',['MIDox implementation of the ALMaSS &lt;em&gt;Osmia bicornis&lt;/em&gt; model',['../index.html',1,'']]],
  ['boundary_1',['7. Reproducibility and version boundary',['../index.html#autotoc_md22',1,'']]]
];

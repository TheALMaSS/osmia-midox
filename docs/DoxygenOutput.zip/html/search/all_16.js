var searchData=
[
  ['parasitised_0',['parasitised',['../classstruct__Osmia.html#afb5cd5e589788f2d3d85742270e74302',1,'struct_Osmia']]],
  ['parasitism_20and_20pesticides_1',['4.4 Mortality, parasitism and pesticides',['../index.html#autotoc_md16',1,'']]],
  ['pest_5fmortality_2',['pest_mortality',['../classstruct__Osmia.html#a8d34cc8f2f6d00c3998123cd0f4b3b5a',1,'struct_Osmia']]],
  ['pesticides_3',['4.4 Mortality, parasitism and pesticides',['../index.html#autotoc_md16',1,'']]],
  ['planeggspernest_4',['PlanEggsPerNest',['../classOsmia__Female.html#afb7cb396b33201c4733f2465bc172f1d',1,'Osmia_Female']]],
  ['population_20level_20control_5',['2.2 Population-level control',['../index.html#autotoc_md7',1,'']]],
  ['provisioning_6',['4.2 Adult reproduction and provisioning',['../index.html#autotoc_md14',1,'']]]
];

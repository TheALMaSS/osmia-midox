var searchData=
[
  ['2_201_20individual_20agents_20and_20stage_20transitions_0',['2.1 Individual agents and stage transitions',['../index.html#autotoc_md6',1,'']]],
  ['2_202_20population_20level_20control_1',['2.2 Population-level control',['../index.html#autotoc_md7',1,'']]],
  ['2_203_20nests_20and_20spatial_20organisation_2',['2.3 Nests and spatial organisation',['../index.html#autotoc_md8',1,'']]],
  ['2_20adult_20reproduction_20and_20provisioning_3',['4.2 Adult reproduction and provisioning',['../index.html#autotoc_md14',1,'']]],
  ['2_20architecture_4',['2. Architecture',['../index.html#autotoc_md5',1,'']]],
  ['2_20inputs_5',['5.2 Inputs',['../index.html#autotoc_md19',1,'']]],
  ['2_20population_20level_20control_6',['2.2 Population-level control',['../index.html#autotoc_md7',1,'']]],
  ['2_20within_20stage_20state_20machines_7',['3.2 Within-stage state machines',['../index.html#autotoc_md11',1,'']]]
];

var searchData=
[
  ['emergence_0',['4.1 Development and emergence',['../index.html#autotoc_md13',1,'']]]
];

var searchData=
[
  ['hasroom_0',['HasRoom',['../classOsmiaPolygonEntry.html#a3b05aa0a08ff53c1fd8d1e4edf3d31ad',1,'OsmiaPolygonEntry::HasRoom()'],['../classOsmia__Nest__Manager.html#ab532d87c221d2659dfc423b530b93541',1,'Osmia_Nest_Manager::HasRoom()'],['../classOsmia__Population__Manager.html#a66393baa09832d4cccd9c3e32bc5b1fe',1,'Osmia_Population_Manager::HasRoom()']]]
];

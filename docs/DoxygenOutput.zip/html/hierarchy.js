var hierarchy =
[
    [ "Osmia_Nest_Manager", "classOsmia__Nest__Manager.html", null ],
    [ "OsmiaNestData", "classOsmiaNestData.html", null ],
    [ "OsmiaParasitoidSubPopulation", "classOsmiaParasitoidSubPopulation.html", null ],
    [ "OsmiaPollenNectarThresholds", "classOsmiaPollenNectarThresholds.html", null ],
    [ "OsmiaPolygonEntry", "classOsmiaPolygonEntry.html", null ],
    [ "Population_Manager", null, [
      [ "OsmiaParasitoid_Population_Manager", "classOsmiaParasitoid__Population__Manager.html", null ],
      [ "Osmia_Population_Manager", "classOsmia__Population__Manager.html", null ]
    ] ],
    [ "struct_Osmia", "classstruct__Osmia.html", null ],
    [ "TAnimalToxicity", null, [
      [ "Osmia_Base", "classOsmia__Base.html", [
        [ "Osmia_Egg", "classOsmia__Egg.html", [
          [ "Osmia_Larva", "classOsmia__Larva.html", [
            [ "Osmia_Prepupa", "classOsmia__Prepupa.html", [
              [ "Osmia_Pupa", "classOsmia__Pupa.html", [
                [ "Osmia_InCocoon", "classOsmia__InCocoon.html", [
                  [ "Osmia_Female", "classOsmia__Female.html", null ]
                ] ]
              ] ]
            ] ]
          ] ]
        ] ]
      ] ],
      [ "Osmia_Nest", "classOsmia__Nest.html", null ]
    ] ]
];
var dir_beadf148b26977315a270a1a6e022e41 =
[
    [ "Osmia.cpp", "Osmia_8cpp.html", "Osmia_8cpp" ],
    [ "Osmia.h", "Osmia_8h.html", "Osmia_8h" ],
    [ "Osmia_Population_Manager.cpp", "Osmia__Population__Manager_8cpp.html", "Osmia__Population__Manager_8cpp" ],
    [ "Osmia_Population_Manager.h", "Osmia__Population__Manager_8h.html", "Osmia__Population__Manager_8h" ]
];
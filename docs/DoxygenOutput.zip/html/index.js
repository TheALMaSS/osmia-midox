var index =
[
    [ "Documentation map", "index.html#autotoc_md1", null ],
    [ "Abstract", "index.html#autotoc_md2", null ],
    [ "1. Introduction", "index.html#autotoc_md3", [
      [ "1.1 Scope", "index.html#autotoc_md4", null ]
    ] ],
    [ "2. Architecture", "index.html#autotoc_md5", [
      [ "2.1 Individual agents and stage transitions", "index.html#autotoc_md6", null ],
      [ "2.2 Population-level control", "index.html#autotoc_md7", null ],
      [ "2.3 Nests and spatial organisation", "index.html#autotoc_md8", null ]
    ] ],
    [ "3. Scheduling and control flow", "index.html#autotoc_md9", [
      [ "3.1 Daily sequence", "index.html#autotoc_md10", null ],
      [ "3.2 Within-stage state machines", "index.html#autotoc_md11", null ]
    ] ],
    [ "4. Implementation details", "index.html#autotoc_md12", [
      [ "4.1 Development and emergence", "index.html#autotoc_md13", null ],
      [ "4.2 Adult reproduction and provisioning", "index.html#autotoc_md14", null ],
      [ "4.3 Nest search, foraging and dispersal", "index.html#autotoc_md15", null ],
      [ "4.4 Mortality, parasitism and pesticides", "index.html#autotoc_md16", null ]
    ] ],
    [ "5. Configuration, inputs and outputs", "index.html#autotoc_md17", [
      [ "5.1 Configuration", "index.html#autotoc_md18", null ],
      [ "5.2 Inputs", "index.html#autotoc_md19", null ],
      [ "5.3 Outputs", "index.html#autotoc_md20", null ]
    ] ],
    [ "6. Implementation differences and retained limitations", "index.html#autotoc_md21", null ],
    [ "7. Reproducibility and version boundary", "index.html#autotoc_md22", null ],
    [ "References", "index.html#autotoc_md23", null ],
    [ "Documentation status", "index.html#autotoc_md24", null ]
];